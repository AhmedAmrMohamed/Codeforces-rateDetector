import cfrate
def main():
    cfrate.main()
