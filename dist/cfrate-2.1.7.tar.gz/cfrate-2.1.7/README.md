# Codeforces-rateDetector
play a file sound - song- once the rating changes at all the participants  of some round. Also if a handle was given the program will output the the changes to that handle

<h4>This is only working on windows; still tryin to figure out how to make it work on linux - I just don't know how ¯\_('_')_/¯ -</h4>
<h3>Install</h3>
    <ol>
        <li>First make sure you got python 3.x and pip installed</li>
        <li>open command-line and type <code>pip install cfrate</code></li>
    </ol>
<h3>Usage</h3>
    <p>open command-line and type <code>cfrate [Contest-ID] [Handle(optional)]</p>
    <p>The first time you run this program it will open <br>a window where you need to copy the media file
        you want to be played when the contest rating change</p>
    <p>simply move/copy the media file into that folder and run the program again</p>
    <If you want to change the media file type in <code>cfrate *</code><br>
<h3>Examples</h3>
<code>cfrate 1066</h3><br>
<code>cfrate 1066 theunderdog</h3><br>
<code>cfrate *</code>
README.md

    
