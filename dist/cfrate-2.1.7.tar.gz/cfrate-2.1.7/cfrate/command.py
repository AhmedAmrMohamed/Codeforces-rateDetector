from cfrate import *
def main():
    cfmain()
